﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapaPresentacion
{
    public partial class Registro : System.Web.UI.Page
    {
        protected void btnRegistrar_Click(object sender, EventArgs e)
        {
            string usuario = txtNuevoUsuario.Text.Trim();
            string contrasena = txtNuevaContrasena.Text.Trim();

            string cadena = ConfigurationManager.ConnectionStrings["JARED"].ConnectionString;

            using (SqlConnection con = new SqlConnection(cadena))
            {
                con.Open();
                string query = "INSERT INTO Usuarios (NombreUsuario, Contrasena) VALUES (@usuario, @pass)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@usuario", usuario);
                cmd.Parameters.AddWithValue("@pass", contrasena); // luego encriptamos esto

                try
                {
                    cmd.ExecuteNonQuery();
                    Response.Write("<script>alert('Registro exitoso. ¡Inicia sesión!');window.location='Login.aspx';</script>");
                }
                catch (SqlException ex)
                {
                    Response.Write("<script>alert('Error: " + ex.Message + "');</script>");
                }
            }
        }
    }
}