﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapaPresentacion
{
    public partial class Catalogo : System.Web.UI.Page
    {
        string conexion = ConfigurationManager.ConnectionStrings["ProductosDB"].ConnectionString;
        protected void btnCerrarSesion_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Response.Redirect("Inicio.aspx");
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["usuario"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            if (!IsPostBack)
            {
                CargarProductos();
            }
            if (Session["usuario"] != null)
            {
                lblUsuario.Text = "Bienvenido, " + Session["usuario"].ToString();
            }
            else
            {
                // Si alguien intenta entrar directo sin login
                Response.Redirect("Login.aspx");
                
            }
        }
private void CargarProductos()
        {
            using (SqlConnection con = new SqlConnection(conexion))
            {
                string query = "SELECT Id, Nombre, Descripcion, Precio, ImagenUrl, CodigoBarras, FechaAgregado FROM Productos";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                gvProductos.DataSource = dt;
                gvProductos.DataBind();
            }
        }


        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text.Trim();
            string descripcion = txtDescripcion.Text.Trim();
            string imagenUrl = txtImagenUrl.Text.Trim();
            decimal precio;

            if (!decimal.TryParse(txtPrecio.Text.Replace(",", "."), System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out precio))
            {
                Response.Write("<script>alert('Precio no válido. Usa punto para decimales (Ej: 25.50)');</script>");
                return;
            }

            using (SqlConnection con = new SqlConnection(conexion))
            {
                string query = "INSERT INTO Productos (Nombre, Descripcion, Precio, ImagenUrl) VALUES (@nombre, @descripcion, @precio, @imagenUrl)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@nombre", nombre);
                cmd.Parameters.AddWithValue("@descripcion", descripcion);
                cmd.Parameters.AddWithValue("@precio", precio);
                cmd.Parameters.AddWithValue("@imagenUrl", imagenUrl);
                
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }

            CargarProductos();
        }
        protected void txtImagenUrl_TextChanged(object sender, EventArgs e)
        {
            imgPreview.ImageUrl = txtImagenUrl.Text;
        }
        protected void gvProductos_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Eliminar")
            {
                int id = Convert.ToInt32(e.CommandArgument);

                using (SqlConnection con = new SqlConnection(conexion))
                {
                    string query = "DELETE FROM Productos WHERE Id = @id";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@id", id);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }

                CargarProductos();
            }
        }
            protected void gvProductos_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvProductos.EditIndex = e.NewEditIndex;
            CargarProductos();
        }

        protected void gvProductos_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvProductos.EditIndex = -1;
            CargarProductos();
        }

        protected void gvProductos_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = gvProductos.Rows[e.RowIndex];

            string nombre = ((TextBox)row.FindControl("txtNombreEdit")).Text;
            string descripcion = ((TextBox)row.FindControl("txtDescripcionEdit")).Text;
            decimal precio = Convert.ToDecimal(((TextBox)row.FindControl("txtPrecioEdit")).Text);

            // 🛠️ Validación segura para el campo de imagen
            TextBox txtImagen = row.FindControl("txtImagen") as TextBox;
            if (txtImagen == null)
            {
                throw new Exception("El control txtImagen no fue encontrado.");
            }
            string imagen = txtImagen.Text;

            string codigo = ((TextBox)row.FindControl("txtCodigoEdit")).Text;

            int id = Convert.ToInt32(gvProductos.DataKeys[e.RowIndex].Value);
            string cadena = ConfigurationManager.ConnectionStrings["ProductosDB"].ConnectionString;

            using (SqlConnection con = new SqlConnection(cadena))
            {
                con.Open();
                string query = "UPDATE Productos SET Nombre=@n, Descripcion=@d, Precio=@p, ImagenUrl=@i, CodigoBarras=@c WHERE Id=@id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@n", nombre);
                cmd.Parameters.AddWithValue("@d", descripcion);
                cmd.Parameters.AddWithValue("@p", precio);
                cmd.Parameters.AddWithValue("@i", imagen);
                cmd.Parameters.AddWithValue("@c", codigo);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
            }

            gvProductos.EditIndex = -1;
            CargarProductos();
        }


        protected void gvProductos_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = Convert.ToInt32(gvProductos.DataKeys[e.RowIndex].Value);

            using (SqlConnection con = new SqlConnection(conexion))
            {
                string query = "DELETE FROM Productos WHERE Id = @id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", id);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }

            CargarProductos();
        }
    }
    }
