﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapaPresentacion
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                if (!string.IsNullOrWhiteSpace(txtUsuario.Text))
                    txtUsuario.CssClass += " not-empty";

                if (!string.IsNullOrWhiteSpace(txtPassword.Text))
                    txtPassword.CssClass += " not-empty";
            }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text.Trim();
            string contrasena = txtPassword.Text.Trim();

            string cadena = ConfigurationManager.ConnectionStrings["JARED"].ConnectionString;

            using (SqlConnection con = new SqlConnection(cadena))
            {
                con.Open();
                string query = "SELECT COUNT(*) FROM Usuarios WHERE NombreUsuario = @usuario AND Contrasena = @pass";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@usuario", usuario);
                cmd.Parameters.AddWithValue("@pass", contrasena);

                int count = (int)cmd.ExecuteScalar();

                if (count == 1)
                {
                    // ✅ Usuario correcto
                    Session["usuario"] = usuario;
                    Response.Redirect("Catalogo.aspx");
                }
                else
                {
                    // ❌ Usuario incorrecto
                    Response.Write("<script>alert('Usuario o contraseña incorrectos');</script>");
                }
            }
        }
    }
}
